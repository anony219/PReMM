if (bytes == null) {
    return null;
} else {
    return new String(bytes, Charsets.ISO_8859_1);
}