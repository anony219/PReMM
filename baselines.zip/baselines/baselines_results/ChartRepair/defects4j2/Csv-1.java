if (current == '\n' || current == '\r') {
    if (lastChar != '\r' || current != '\n') // avoid counting twice for '\r\n'