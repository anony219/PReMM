if (cs1.length() != cs2.length()) {
    return false;
}
for (int i = 0; i < cs1.length(); i++) {
    if(cs1.charAt(i) != cs2.charAt(i)) {
        return false;
    }
}
return true;