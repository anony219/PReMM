jsDocParameter.getJSType(), 
jsDocParameter.isOptionalArg() || jsDocParameter.isVarArgs());