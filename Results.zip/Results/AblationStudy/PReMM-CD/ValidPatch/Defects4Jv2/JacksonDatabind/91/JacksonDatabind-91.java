private boolean _hasCustomHandlers(JavaType t) {
    if (t.isContainerType()) {
        // First: value types may have both value and type handlers
        JavaType ct = t.getContentType();
        if (ct != null) {
            boolean hasValueHandler = (ct.getValueHandler() != null);
            boolean hasTypeHandler = (ct.getTypeHandler() != null);
            if (hasValueHandler || hasTypeHandler) {
                return true;
            }
        }
        // Second: map(-like) types may have value handler for key (but not type; keys are untyped)
        if (t.isMapLikeType()) {
            return (t.getKeyType().getValueHandler() != null);
        }
    }
    return false;
}