    @Deprecated
    public JavaType constructType(Type type, Class<?> contextClass) {
        if (contextClass == null) {
            return constructType(type, (JavaType) null);
        }
        return constructType(type, constructType(contextClass));
    }    @Deprecated
    public JavaType constructType(Type type, JavaType contextType) {
        if (contextType == null) {
            return _fromAny(null, type, null);
        }
        return _fromAny(null, type, contextType.getBindings());
    }