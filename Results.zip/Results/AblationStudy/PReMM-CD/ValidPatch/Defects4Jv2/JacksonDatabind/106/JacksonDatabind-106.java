    @Override
    public int getIntValue() throws IOException {
        final NumericNode node = (NumericNode) currentNumericNode();
        if (node.canConvertToInt()) {
            return node.intValue();
        } else {
            throw new IOException("Cannot convert value to int: " + node);
        }
    }    @Override
    public long getLongValue() throws IOException {
        NumericNode node = (NumericNode) currentNumericNode();
        if (node == null) {
            throw new IOException("Current node is not a numeric node");
        }
        return node.longValue();
    }