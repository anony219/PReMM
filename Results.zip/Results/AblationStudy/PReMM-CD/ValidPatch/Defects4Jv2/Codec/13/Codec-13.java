public boolean isDoubleMetaphoneEqual(final String value1, final String value2, final boolean alternate) {
    if (value1 == null || value2 == null) {
        return value1 == value2;
    }
    if (value1.isEmpty() && value2.isEmpty()) {
        return true;
    }
    if (value1.isEmpty() || value2.isEmpty()) {
        return false;
    }
    return doubleMetaphone(value1, alternate).equals(doubleMetaphone(value2, alternate));
}