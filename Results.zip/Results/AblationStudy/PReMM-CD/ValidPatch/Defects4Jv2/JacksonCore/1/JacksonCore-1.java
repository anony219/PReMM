public static BigDecimal parseBigDecimal(String numStr) throws NumberFormatException {
    if (numStr == null || numStr.isEmpty()) {
        throw new NumberFormatException("Input string is null or empty");
    }
    if (numStr.equalsIgnoreCase("NaN") || numStr.equalsIgnoreCase("Infinity") || numStr.equalsIgnoreCase("-Infinity")) {
        throw new NumberFormatException(numStr + " can not be represented as BigDecimal");
    }
    return new BigDecimal(numStr);
}public static BigDecimal parseBigDecimal(char[] buffer, int offset, int len)
    throws NumberFormatException
{
    String value = new String(buffer, offset, len);
    if (value.equalsIgnoreCase("NaN") || value.equalsIgnoreCase("Infinity") || value.equalsIgnoreCase("-Infinity")) {
        throw new NumberFormatException("'" + value + "' can not be represented as BigDecimal");
    }
    return new BigDecimal(value);
}public BigDecimal contentsAsDecimal()
    throws NumberFormatException
{
    // Already got a pre-cut array?
    if (_resultArray != null) {
        return NumberInput.parseBigDecimal(_resultArray);
    }
    // Or a shared buffer?
    if (_inputLen > 0) {
        return NumberInput.parseBigDecimal(_inputBuffer, _inputStart, _inputLen);
    }
    // Or if not, just a single buffer (the usual case)
    if (_currentSize > 0) {
        return NumberInput.parseBigDecimal(_currentSegment, 0, _currentSize);
    }
    // If not, let's just get it aggregated...
    return NumberInput.parseBigDecimal(contentsAsArray());
}