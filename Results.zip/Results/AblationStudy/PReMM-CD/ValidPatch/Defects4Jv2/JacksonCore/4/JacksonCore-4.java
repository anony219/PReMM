public char[] expandCurrentSegment() {
    final char[] curr = _currentSegment;
    final int len = curr.length;
    int newLen;

    if (len >= MAX_SEGMENT_LEN) {
        // If the current length is at or above the maximum, increase by a fixed amount
        newLen = len + (len >> 2); // Increase by 25% of the current length
    } else {
        // Otherwise, increase by 50% of the current length
        newLen = Math.min(MAX_SEGMENT_LEN, len + (len >> 1));
    }

    return (_currentSegment = Arrays.copyOf(curr, newLen));
}