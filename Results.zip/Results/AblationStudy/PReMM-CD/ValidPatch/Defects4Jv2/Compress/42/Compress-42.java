    public boolean isUnixSymlink() {
        return (getUnixMode() & UnixStat.LINK_FLAG) == UnixStat.LINK_FLAG && (getUnixMode() & UnixStat.FILE_FLAG) == 0;
    }