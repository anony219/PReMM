protected void setName(String name) {
    this.name = name.replace("\\", "/");
}