public static long skip(InputStream input, long numToSkip) throws IOException {
    long totalSkipped = 0;
    while (numToSkip > 0) {
        long skipped = input.skip(numToSkip);
        if (skipped > 0) {
            totalSkipped += skipped;
            numToSkip -= skipped;
        } else {
            // If skip returns 0, read one byte at a time
            int b = input.read();
            if (b == -1) {
                // End of stream reached
                break;
            }
            totalSkipped++;
            numToSkip--;
        }
    }
    return totalSkipped;
}