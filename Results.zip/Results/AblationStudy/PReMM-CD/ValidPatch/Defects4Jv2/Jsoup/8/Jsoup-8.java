protected void outerHtml(StringBuilder accum) {
    Document doc = ownerDocument();
    Document.OutputSettings outputSettings = (doc != null) ? doc.outputSettings() : new Document("").outputSettings();
    new NodeTraversor(new OuterHtmlVisitor(accum, outputSettings)).traverse(this);
}