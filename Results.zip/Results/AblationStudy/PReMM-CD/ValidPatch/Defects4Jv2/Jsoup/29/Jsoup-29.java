public String title() {
    // title is a preserve whitespace tag (for document output), but normalised here
    Element titleEl = getElementsByTag("title").first();
    return titleEl != null ? titleEl.text().replaceAll("\\s+", " ").trim() : "";
}