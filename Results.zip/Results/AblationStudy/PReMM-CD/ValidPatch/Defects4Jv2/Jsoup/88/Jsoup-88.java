public String getValue() {
    return val == null ? "" : val;
}