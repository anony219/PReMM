private boolean isOneExactlyFunctionOrDo(Node n) {
    // Check if the node is a FUNCTION or DO
    if (n.getType() == Token.FUNCTION || n.getType() == Token.DO) {
        return true;
    }

    // Check if the node is a BLOCK
    if (n.getType() == Token.BLOCK) {
        // If the block has exactly one child, check if that child is a FUNCTION or DO
        Node child = n.getFirstChild();
        if (child != null && child.getNext() == null) {
            return isOneExactlyFunctionOrDo(child);
        }
    }

    // Check if the node is a LABEL
    if (n.getType() == Token.LABEL) {
        // Check if the labeled statement is a FUNCTION or DO
        Node labeledStatement = n.getFirstChild().getNext();
        if (labeledStatement != null) {
            return isOneExactlyFunctionOrDo(labeledStatement);
        }
    }

    // If the node is not a FUNCTION, DO, or a BLOCK with a single FUNCTION or DO child, return false
    return false;
}