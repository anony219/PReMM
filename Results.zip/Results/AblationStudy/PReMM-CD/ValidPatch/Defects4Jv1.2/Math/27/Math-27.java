public double percentageValue() {
    return (doubleValue() * 100);
}