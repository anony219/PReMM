    @Deprecated
    public void addValue(Object v) {
        if (!(v instanceof Comparable)) {
            throw new IllegalArgumentException("Object is not comparable");
        }
        addValue((Comparable<?>) v);
    }