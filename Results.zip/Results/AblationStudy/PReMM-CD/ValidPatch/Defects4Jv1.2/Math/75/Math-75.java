    @Deprecated
    public double getPct(Object v) {
        if (v instanceof Comparable) {
            Comparable<?> comparableValue = (Comparable<?>) v;
            long count = getCount(comparableValue);
            long totalCount = getSumFreq();
            if (totalCount > 0) {
                return (double) count / totalCount;
            }
        }
        return 0.0;
    }
