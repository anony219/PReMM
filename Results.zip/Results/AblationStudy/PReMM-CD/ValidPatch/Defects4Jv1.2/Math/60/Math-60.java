public double cumulativeProbability(double x) throws MathException {
    final double dev = x - mean;

    // Handle infinite values directly
    if (Double.isInfinite(x)) {
        return x < 0 ? 0.0 : 1.0;
    }

    // Handle very large and very small values without calling Erf.erf
    if (x < (mean - 20 * standardDeviation)) {
        return 0.0;
    } else if (x > (mean + 20 * standardDeviation)) {
        return 1.0;
    }

    try {
        // Calculate the cumulative probability using Erf.erf
        return 0.5 * (1.0 + Erf.erf(dev / (standardDeviation * FastMath.sqrt(2.0))));
    } catch (MaxIterationsExceededException ex) {
        // If Erf.erf fails to converge, return a reasonable approximation
        if (x < mean) {
            return 0.0;
        } else {
            return 1.0;
        }
    }
}