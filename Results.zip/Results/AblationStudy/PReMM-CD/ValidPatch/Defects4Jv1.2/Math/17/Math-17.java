public Dfp multiply(final int x) {
    // Convert the integer to a Dfp object
    Dfp other = field.newDfp(x);
    // Use the Dfp multiply method to handle the multiplication
    return this.multiply(other);
}