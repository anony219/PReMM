public double cumulativeProbability(double x) throws MathException {
    if (x == Double.NEGATIVE_INFINITY) {
        return 0.0;
    } else if (x == Double.POSITIVE_INFINITY) {
        return 1.0;
    } else {
        // Ensure the input to Erf.erf is within a safe range
        double z = (x - mean) / (standardDeviation * Math.sqrt(2.0));
        if (z < -10.0) {
            return 0.0;
        } else if (z > 10.0) {
            return 1.0;
        } else {
            return 0.5 * (1.0 + Erf.erf(z));
        }
    }
}