public Week(Date time, TimeZone zone) {
    // defer argument checking...
    this(time, zone, Locale.getDefault());
}