public double getMaximumExplodePercent() {
    double result = 0.0;
    if (this.dataset == null) {
        return result;
    }
    Iterator iterator = this.dataset.getKeys().iterator();
    while (iterator.hasNext()) {
        Comparable key = (Comparable) iterator.next();
        Number explode = (Number) this.explodePercentages.get(key);
        if (explode != null) {
            result = Math.max(result, explode.doubleValue());   
        }
    }
    return result;
}public PiePlotState initialise(Graphics2D g2, Rectangle2D plotArea, PiePlot plot, Integer index, PlotRenderingInfo info) {
    PiePlotState state = new PiePlotState(info);
    state.setPassesRequired(2);
    if (plot.getDataset() != null) {
        state.setTotal(DatasetUtilities.calculatePieDatasetTotal(plot.getDataset()));
    } else {
        state.setTotal(0);
    }
    state.setLatestAngle(plot.getStartAngle());
    return state;
}