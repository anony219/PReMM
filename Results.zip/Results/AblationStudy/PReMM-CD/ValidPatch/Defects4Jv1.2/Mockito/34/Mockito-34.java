public void captureArgumentsFrom(Invocation i) {
    int k = 0;
    Object[] args = i.getArguments();
    for (Matcher m : matchers) {
        if (k < args.length && m instanceof CapturesArguments) {
            ((CapturesArguments) m).captureFrom(args[k]);
        }
        k++;
    }
}