private String formatMethodCall() {
			StringBuilder sb = new StringBuilder();
			sb.append(invocation.getMethod().getName()).append("(");
			for (int i = 0; i < invocation.getArguments().length; i++) {
				sb.append(invocation.getArguments()[i]);
				if (i < invocation.getArguments().length - 1) {
					sb.append(", ");
				}
			}
			sb.append(")");
			return sb.toString();
		}