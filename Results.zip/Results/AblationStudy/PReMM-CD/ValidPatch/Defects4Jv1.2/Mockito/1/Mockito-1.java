    public void captureArgumentsFrom(Invocation invocation) {
        if (invocation.getMethod().isVarArgs()) {
            int indexOfVararg = invocation.getRawArguments().length - 1;
            Object varargs = invocation.getRawArguments()[indexOfVararg];
            if (varargs instanceof Object[]) {
                for (int i = 0; i < ((Object[]) varargs).length; i++) {
                    captureFromVararg(invocation, indexOfVararg, i, (Object[]) varargs);
                }
            }
        } else {
            for (int position = 0; position < matchers.size(); position++) {
                Matcher m = matchers.get(position);
                if (m instanceof CapturesArguments) {
                    ((CapturesArguments) m).captureFrom(invocation.getArgumentAt(position, Object.class));
                }
            }
        }
    }

    private void captureFromVararg(Invocation invocation, int varargIndex, int varargPosition, Object[] varargs) {
        for (int position = 0; position < matchers.size(); position++) {
            Matcher m = matchers.get(position);
            if (m instanceof CapturesArguments && position == varargIndex) {
                ((CapturesArguments) m).captureFrom(varargs[varargPosition]);
            }
        }
    }