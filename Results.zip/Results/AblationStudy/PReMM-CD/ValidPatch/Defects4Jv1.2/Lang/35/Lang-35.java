public static <T> T[] add(T[] array, T element) {
    if (array == null && element == null) {
        throw new IllegalArgumentException("Both array and element cannot be null");
    }
    Class<?> type;
    if (array != null) {
        type = array.getClass().getComponentType();
    } else {
        type = element.getClass();
    }
    @SuppressWarnings("unchecked") // type must be T
    T[] newArray = (T[]) Array.newInstance(type, array == null ? 1 : array.length + 1);
    if (array != null) {
        System.arraycopy(array, 0, newArray, 0, array.length);
    }
    newArray[newArray.length - 1] = element;
    return newArray;
}public static <T> T[] add(T[] array, int index, T element) {
    Class<?> clss = null;
    if (array != null) {
        clss = array.getClass().getComponentType();
    } else if (element != null) {
        clss = element.getClass();
    } else {
        throw new IllegalArgumentException("Both array and element cannot be null");
    }
    @SuppressWarnings("unchecked") // the add method creates an array of type clss, which is type T
    final T[] newArray = (T[]) add(array, index, element, clss);
    return newArray;
}