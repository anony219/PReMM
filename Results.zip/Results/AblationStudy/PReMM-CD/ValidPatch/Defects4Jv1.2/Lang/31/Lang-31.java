public static boolean containsAny(CharSequence cs, char[] searchChars) {
    if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
        return false;
    }
    int csLength = cs.length();
    int searchLength = searchChars.length;
    for (int i = 0; i < csLength; ) {
        int csCodePoint = Character.codePointAt(cs, i);
        for (int j = 0; j < searchLength; ) {
            int searchCodePoint = Character.codePointAt(searchChars, j, searchLength);
            if (csCodePoint == searchCodePoint) {
                return true;
            }
            j += Character.charCount(searchCodePoint);
        }
        i += Character.charCount(csCodePoint);
    }
    return false;
}