    @Override
    public JSType caseObjectType(ObjectType type) {
      if (value.equals("function")) {
        JSType ctorType = getNativeType(U2U_CONSTRUCTOR_TYPE);
        if (ctorType.isSubtype(type)) {
          return resultEqualsValue ? ctorType : type;
        }
        return null;
      }
      return matchesExpectation("object") ? type : null;
    }