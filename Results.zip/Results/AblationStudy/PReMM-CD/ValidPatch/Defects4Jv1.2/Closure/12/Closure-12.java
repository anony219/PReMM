private boolean hasExceptionHandler(Node cfgNode) {
  while (cfgNode != null) {
    if (cfgNode.isTry()) {
      return true;
    }
    cfgNode = cfgNode.getParent();
  }
  return false;
}