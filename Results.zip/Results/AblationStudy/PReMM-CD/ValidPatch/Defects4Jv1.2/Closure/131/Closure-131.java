public static boolean isJSIdentifier(String s) {
  int length = s.length();

  if (length == 0 || !Character.isJavaIdentifierStart(s.charAt(0))) {
    return false;
  }

  for (int i = 1; i < length; i++) {
    char c = s.charAt(i);
    if (!Character.isJavaIdentifierPart(c) || !isAllowedInJSIdentifier(c)) {
      return false;
    }
  }

  return true;
}

private static boolean isAllowedInJSIdentifier(char c) {
  // Check for Unicode characters that are not allowed in JavaScript identifiers
  return !(c >= 0x0000 && c <= 0x001F) && // Control characters
         !(c >= 0x007F && c <= 0x009F) && // Control characters
         !(c >= 0x0600 && c <= 0x0604) && // Arabic number sign, etc.
         !(c >= 0x070F && c <= 0x070F) && // Syriac abbreviation mark
         !(c >= 0x17B4 && c <= 0x17B5) && // Khmer vowels
         !(c >= 0x200C && c <= 0x200F) && // Zero width joiners and direction marks
         !(c >= 0x2028 && c <= 0x202F) && // Line and paragraph separators, etc.
         !(c >= 0x2060 && c <= 0x206F) && // Invisibility and format characters
         !(c >= 0xFEFF && c <= 0xFEFF) && // Zero width no-break space
         !(c >= 0xFFF9 && c <= 0xFFFC) && // Object replacement character, etc.
         !(c >= 0xFFFE && c <= 0xFFFF); // Non-characters
}