static boolean isSimpleNumber(String s) {
  int len = s.length();
  if (len == 0) {
    return false;
  }
  if (s.startsWith("0x") || s.startsWith("0X")) {
    return false;
  }
  if (s.startsWith("0") && len > 1) {
    return false;
  }
  int dotCount = 0;
  for (int index = 0; index < len; index++) {
    char c = s.charAt(index);
    if (c == '.') {
      dotCount++;
      if (dotCount > 1) {
        return false;
      }
    } else if (c < '0' || c > '9') {
      return false;
    }
  }
  return dotCount == 0;
}