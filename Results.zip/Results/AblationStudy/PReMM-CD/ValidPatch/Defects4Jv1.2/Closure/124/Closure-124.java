private boolean isSafeReplacement(Node node, Node replacement) {
  // No checks are needed for simple names.
  if (node.isName()) {
    return true;
  }

  // If the node is not a property access, it's not safe to replace.
  if (!node.isGetProp()) {
    return false;
  }

  // Recursively check the base object and all levels of property access.
  Node base = node.getFirstChild();
  Node current = base;
  while (current != null) {
    if (current.isName() && isNameAssignedTo(current.getString(), replacement)) {
      return false;
    }
    if (current.isGetProp()) {
      current = current.getFirstChild();
    } else {
      current = current.getNext();
    }
  }

  return true;
}