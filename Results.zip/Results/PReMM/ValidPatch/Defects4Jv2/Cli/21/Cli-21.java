public boolean looksLikeOption(final String trigger)
{
    // this is a reentrant call

    if (trigger.matches("^-\\d+(\\.\\d+)?$")) {
        return false;
    }

    for (final Iterator i = prefixes.iterator(); i.hasNext();)
    {
        final String prefix = (String) i.next();

        if (trigger.startsWith(prefix))
        {
            return true;
        }
    }
    return false;
}private boolean looksLikeOption(final WriteableCommandLine commandLine,
        final String trigger) {
        if (trigger.matches("^-\\d+(\\.\\d+)?$")) {
            return false;
        }
        return commandLine.looksLikeOption(trigger);
}